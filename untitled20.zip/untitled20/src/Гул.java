public class Гул {
    String сорт ;
    int свежасть ;
    int цена ;
    ///

    @Override
    public String toString() {
        return "Гул{" +
                "сорт='" + сорт + '\'' +
                ", свежасть=" + свежасть +
                ", цена=" + цена +
                '}';
    }

    public Гул(String сорт, int свежасть, int цена) {
        this.сорт = сорт;
        this.свежасть = свежасть;
        this.цена = цена;

    }
}
